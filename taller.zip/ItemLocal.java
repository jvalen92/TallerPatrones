class ItemLocal extends Item{
    
    @Override
    public void consultarEstado(){
        System.out.println("Estoy en el local");
    }
}