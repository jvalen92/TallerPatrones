class TipoLegal extends TipoItem{
    
    @Override
    public void validarLegaliad(){
        System.out.println("Hola soy un ubjeto legal ");
    }
}