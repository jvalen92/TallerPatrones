public abstract class AbstractFactory {
    public  Cliente getCliente(String ClienteType){
        return null;
    }

    public Factura getFactura(String facturaType){
        return null;
    }

    public Item getItem(String itemType){
        return null;
    }

    public TipoItem getTypeItem(String typeItem ){
        return null;
    }

    
    
}