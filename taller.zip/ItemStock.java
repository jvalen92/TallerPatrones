class ItemStock extends Item {

    @Override
    public void consultarEstado(){
        System.out.println("Estoy en stock");
    }
}