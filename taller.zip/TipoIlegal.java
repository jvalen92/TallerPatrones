class TipoIlegal extends TipoItem{
    
    @Override
    public void validarLegaliad(){
        System.out.println("Hola soy un ubjeto ilegal ");
    }
}