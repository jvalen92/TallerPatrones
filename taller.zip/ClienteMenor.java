class ClienteMenor extends Cliente {
    
    @Override
    public void saludar(){
        System.out.println("Hola soy menor de edad");
    }


}