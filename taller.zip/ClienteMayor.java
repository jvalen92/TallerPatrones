class ClienteMayor extends Cliente{

    @Override
    public void saludar(){
        System.out.println("Hola soy un mayor de edad");
    }
}